<?php include "header.php" ?>

    <!-- hero carousal  -->
    <div id="carouselHeoFade" class="carousel slide carousel-fade position-relative">
        <div class="carousel-indicators m-0 p-0">
            <div class="d-grid gap-1">
                <div data-bs-target="#carouselHeoFade" data-bs-slide-to="0" class="active " aria-current="true"
                    aria-label="Slide 1">
                    <p class="ps-4 pt-10">Principles</p>
                </div>
                <div data-bs-target="#carouselHeoFade" data-bs-slide-to="1" aria-current="true" aria-label="Slide 2">
                    <p class="ps-4 pt-10">Investment</p>
                </div>
                <div data-bs-target="#carouselHeoFade" data-bs-slide-to="2" aria-current="true" aria-label="Slide 3">
                    <p class="ps-4 pt-10">Criteria</p>
                </div>
            </div>
        </div>

        <div class="carousel-inner">
            <div class="carousel-item active">
                <!-- hero 1 -->
                <div class="hero-section text-white pb-100 h-100 hero-spacing">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <h4 class="small fw-bold body-font pb-10 text-uppercase">INVESTMENT PRINCIPLES</h4>
                                <hr class="trans--grow hr1">
                                <h1 class="fw-normal pt-10 pb-3">Our investment activity is guided by the following core principles,<span
                                        class="d-block">largest and
                                        most experienced</span> formed over the course of decades of private equity investing
                                </h1>
                                <a href="#" class="btn btn-primary">find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- hero 1 end -->
            </div>
            <div class="carousel-item">
                <!-- hero 2 -->
                <div class="hero-section hero-bg-image-2 text-white pb-100 h-100 hero-spacing">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <p class="fw-bold heading-font text-uppercase mb-2">PRIVATE EQUITY INVESTORS</p>
                                <h1 class="display-1 text-uppercase body-font fw-normal pb-3 mb-0">Expert Team</h1>
                                <hr class="trans--grow hr1 mt-0 mb-3">
                                <p class="pb-20">We have established a team investment professionals,
                                    <span class="d-block">focused on buyouts and growth equity investments.</span>
                                </p>
                                <a href="#" class="btn btn-primary">find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- hero 2 end -->
            </div>
            <div class="carousel-item">
                <!-- hero 3 -->
                <div class="hero-section hero-bg-image-3 text-white pb-100 h-100 hero-spacing">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-9">
                                <div class="text-center">
                                    <h4 class="fs-6 fw-bold body-font mb-0 text-uppercase custom-letter-spacing">THE
                                        MOST
                                        EXPERIENCED</h4>
                                    <h2 class="display-4 fw-bold custom-letter-spacing-n">
                                        Private Equity Investors Team </h2>
                                    <p class="pb-20"><span class="d-block">We have establishe a team investment
                                            profesionals,
                                            focused</span>
                                        on buyouts and growth equity investments.</p>
                                    <a href="#" class="btn btn-primary">find out more<i
                                            class="icon-arrows-slim-right ps-1"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- hero 3 end -->
            </div>
        </div>


        <button class="carousel-control-prev" type="button" data-bs-target="#carouselHeoFade" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselHeoFade" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <!-- hero carousal end -->

    <!-- hero content -->
    <section class="bg-light">
        <div class="container">
            <div class="row g-1">
                <div class="col-lg-2 col-6">
                    <div class="square-menu position-relative w-100 h-100">
                        <div class="figure-block position-relative d-grid gap-10 text-white">
                            <span>
                                <i class="perch perch-integrity display-4"></i>
                            </span>
                            <h5 class="small text-uppercase">CULTURE OF INTEGRITY</h5>
                        </div>
                        <div class="figcaption mw-100 w-100 pe-0 position-absolute">
                            <a href="#" class="btn btn-sm btn-outline-secondary">Know more</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="square-menu position-relative w-100 h-100">
                        <div class="figure-block position-relative d-grid gap-10 text-white">
                            <span>
                                <i class="perch perch-middle-market display-4"></i>
                            </span>
                            <h5 class="small text-uppercase">OPERATOR-FIRST PHILOSOPHY</h5>
                        </div>
                        <div class="figcaption mw-100 w-100 pe-0 position-absolute">
                            <a href="#" class="btn btn-sm btn-outline-secondary">Know more</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="square-menu position-relative w-100 h-100">
                        <div class="figure-block position-relative d-grid gap-10 text-white">
                            <span>
                                <i class="perch perch-operator-first display-4"></i>
                            </span>
                            <h5 class="small text-uppercase">FOCUS MARKET SEGMENTATION</h5>
                        </div>
                        <div class="figcaption mw-100 w-100 pe-0 position-absolute">
                            <a href="#" class="btn btn-sm btn-outline-secondary">Know more</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="square-menu position-relative w-100 h-100">
                        <div class="figure-block position-relative d-grid gap-10 text-white">
                            <span>
                                <i class="perch perch-value display-4"></i>
                            </span>
                            <h5 class="small text-uppercase">VALUE ADDED ORIENTATION
                            </h5>
                        </div>
                        <div class="figcaption mw-100 w-100 pe-0 position-absolute">
                            <a href="#" class="btn btn-sm btn-outline-secondary">Know more</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="square-menu position-relative w-100 h-100">
                        <div class="figure-block position-relative d-grid gap-10 text-white">
                            <span>
                                <i class="perch perch-middle-market display-4"></i>
                            </span>
                            <h5 class="small text-uppercase">FOCUS LOWER MIDDLE-MARKET</h5>
                        </div>
                        <div class="figcaption mw-100 w-100 pe-0 position-absolute">
                            <a href="#" class="btn btn-sm btn-outline-secondary">Know more</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="square-menu position-relative w-100 h-100">
                        <div class="figure-block position-relative d-grid gap-10 text-white">
                            <span>
                                <i class="perch perch-strategy display-4"></i>
                            </span>
                            <h5 class="small text-uppercase">BUY & BUILD STRATEGIES</h5>
                        </div>
                        <div class="figcaption mw-100 w-100 pe-0 position-absolute">
                            <a href="#" class="btn btn-sm btn-outline-secondary">Know more</a>
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
            <div class="col-lg-4">
                        <div class="position-relative bg-primary text-white">
                            <div class="pt-4 ps-60 pb-30">
                                <i class="icon-arrows-slim-right icon-arrows-large arrow-icon-nmargin-l"></i>
                                <h5 class="small text-uppercase">Middle-market private equity</h5>
                                <h1 class="display-1 body-font fw-bold lh-1 mb-0">H.F.A</h1>
                                <p class="mb-0">12 Offices in 11 Countries</p>
                            </div>
                            <div class="position-relative pt-4 ps-60 pb-30 invested">
                                <i class="icon-arrows-slim-right icon-arrows-large arrow-icon-nmargin-l"></i>
                                <h5 class="small text-uppercase">Invested</h5>
                                <h1 class="display-1 body-font fw-bold lh-1 mb-0">$2.4 <span
                                        class="fs-1 body-font fw-bold">B</span>
                                </h1>
                            </div>
                        </div>
                    </div>
            <div class="bg-white">
                <div class="row gx-1">
                    <div class="col-lg-8">
                        <div class="px-30 px-lg-5 pt-40 pb-20">
                            <div class="row gx-30">
                                
                                <div class="col-lg-6 ">
                                    <p class="text-muted fs-4 fw-light"><span
                                            class="fs-4 fw-normal text-dark text-opacity-75">Single greatest determinant of investment performance is entry price</span> 
                                            <ul>
<li>
Maintain rigorous price discipline on entry, as there is no solution to overpaying

</li>
<li>
Market dislocations create excellent entry opportunities
</li>
                                            </ul>
</p>
                                </div>

                                <div class="col-lg-6 ">
                                    <p class="text-muted fs-4 fw-light"><span
                                            class="fs-4 fw-normal text-dark text-opacity-75">Industry leaders are generally in that position for good reasons, and broken companies are often broken for good reasons</span>

                                            <ul>
<li>
Buy good businesses and invest behind strong managers
</li>
<li>
Do not presume you can fix what others have tried and failed to solve
</li>
                                            </ul>
</p>
                                </div>



                                <div class="col-lg-6">
                                    <p class="fs-4 fw-normal text-dark text-opacity-75">Stable businesses with strong cash flow profiles make for great investments</p>
                                    <p class="text-dark text-opacity-75">
                                    <ul>
<li>
Avoid fashionable sectors

</li>
<li>
Prize cash flow generation and sustainability
</li>
                                            </ul>
                                    </p>
                                </div>
                                <div class="col-lg-6 ">
                                    <p class="text-muted fs-4 fw-light"><span
                                            class="fs-4 fw-normal text-dark text-opacity-75">Assume nothing and maintain a meticulous attention to detail</span>
                                            <ul>
<li>
Perform due diligence without preconceptions
</li>
<li>
Listen closely to those who disagree
</li>
                                            </ul>
                                         
</p>
                                </div>

                                <div class="col-lg-6">
                                    <p class="fs-4 fw-normal text-dark text-opacity-75">Strong management team is critical to investment success</p>
                                    <p class="text-dark text-opacity-75">
                                    <ul>
<li>
Diligence management extensively


</li>
<li>
Align incentives and create true wealth-creation opportunities deep into the organization
</li>
                                            </ul>
                                    </p>
                                </div>
                                <div class="col-lg-6 ">
                                    <p class="text-muted fs-4 fw-light"><span
                                            class="fs-4 fw-normal text-dark text-opacity-75">No one ever regrets a conservative capital structure</span>
                                            <ul>
<li>
Take less leverage than offered

</li>
<li>
Choose flexibility over pricing
</li>
                                            </ul>
                                         
</p>
                                </div>


                                <div class="col-lg-6">
                                    <p class="fs-4 fw-normal text-dark text-opacity-75">Be aware of the chess pieces on the board</p>
                                    <p class="text-dark text-opacity-75">
                                    <ul>
<li>
Note the various stakeholders surrounding an opportunity and consider how their interests align with yours
</li>
<li>
Look for the exceptional opportunities created when macro forces align
</li>
                                            </ul>
                                    </p>

                            </div>
                            <div class="col-lg-6 ">
                                    <p class="text-muted fs-4 fw-light"><span
                                            class="fs-4 fw-normal text-dark text-opacity-75">Sell when the sun is shining</span>
                                            <ul>
<li>
Waiting for a slightly higher price is a bad risk / reward tradeoff on successful investments

</li>
                                     </ul>
                                         
</p>
                                </div>

                                <div class="col-lg-6">
                                    <p class="fs-4 fw-normal text-dark text-opacity-75">Smart capital around the table leads to better outcomes</p>
                                    <p class="text-dark text-opacity-75">
                                    <ul>
<li>
Partner with other investors who can add value
No monopoly on good ideas, no ego and no pride of authorship
</li>
<li>
No monopoly on good ideas, no ego and no pride of authorship
</li>
                                            </ul>
                                    </p>

                            </div>
                            <div class="col-lg-6 ">
                                    <p class="text-muted fs-4 fw-light"><span
                                            class="fs-4 fw-normal text-dark text-opacity-75">An Old-School approach and personal integrity lead to better investment outcomes and opportunities</span>
                                            <ul>
<li>
Behave honorably. Reputation as a good partner and honest broker is critical to current and future success
Only work with those you respect and trust

</li>

<li>
Only work with those you respect and trust

</li>
                                     </ul>
                                         
</p>
                                </div>
                                  <div class="col-lg-6">
                                    <p class="fs-4 fw-normal text-dark text-opacity-75">There is always another card to play</p>
                                    <p class="text-dark text-opacity-75">
                                    <ul>
<li>
Remain focused during setbacks to optimize outcome
</li>
                                            </ul>
                                    </p>

                            </div>


                        </div>
                    </div>
                  
                </div>
            </div>
        </div>
    </section>
    <!-- hero content end-->

    <!-- isotop section  -->
    <section class="isotop-section bg-dark">

        <div class="bg-secondary d-flex justify-content-between flex-wrap py-30 ps-20 pe-4 mb-20">
            <h2 class="text-white mb-0">Hill-FinAdvisor</h2>
            <div class="item-menu">
                <ul class=" list-inline mb-0">
                    <li class="list-inline-item active" data-filter=".all">All</li>
                    <li class="list-inline-item" data-filter=".energy">Energy</li>
                    <li class="list-inline-item" data-filter=".financials">Financials</li>
                    <li class="list-inline-item" data-filter=".industrial">Industrial</li>
                    <li class="list-inline-item" data-filter=".information-tehnology">Information tehnology</li>
                    <li class="list-inline-item" data-filter=".materials">Materials</li>
                </ul>
            </div>
        </div>

        <div class="px-20 pb-20">
            <div class="row g-1 item-details ">

                <div class="col-lg-4 col-md-6 item energy">
                    <div class="px-30 bg-secondary text-white pt-4 pb-20 h-100 isotop-block">
                        <h4 class="text-underline-sm lh-1 pb-3 mb-3 pt-0">Energy</h4>
                        <p class="small mb-20">We invest in five corere industry sectors where we have substantial
                            experience
                            and deep local
                            and international knowle Business & Financial Services; Healthcare; Industrial; Retail,
                            Consumer & Leisure; Technology, Media & Telecom.</p>
                        <a href="#" class="btn btn-outline-primary">know more<i
                                class="icon-arrows-slim-right ps-2"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 item financials">
                    <div class="px-30 bg-secondary text-white pt-4 pb-20 h-100 isotop-block">
                        <h4 class="text-underline-sm lh-1 pb-3 mb-3 pt-0">Financials</h4>
                        <p class="small mb-20">We invest in five corere industry sectors where we have substantial
                            experience
                            and deep local
                            and international knowle Business & Financial Services; Heahcare; Indtustrial; Retail,
                            Consumer & Leisure; Technology, Media & Telecom.</p>
                        <a href="#" class="btn btn-outline-primary">know more<i
                                class="icon-arrows-slim-right ps-2"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 item industrial">
                    <div class="px-30 bg-secondary text-white pt-4 pb-20 h-100 isotop-block">
                        <h4 class="text-underline-sm lh-1 pb-3 mb-3 pt-0">Industrial</h4>
                        <p class="small mb-20">We invest in five corere industry sectors where we have substantial
                            experience
                            and deep local
                            and international knowle Business & Financial Services; Heahcare; Indtustrial; Retail,
                            Consumer & Leisure; Technology, Media & Telecom.</p>
                        <a href="#" class="btn btn-outline-primary">know more<i
                                class="icon-arrows-slim-right ps-2"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 item information-tehnology">
                    <div class="px-30 bg-secondary text-white pt-4 pb-20 h-100 isotop-block">
                        <h4 class="text-underline-sm lh-1 pb-3 mb-3 pt-0">Information tehnology</h4>
                        <p class="small mb-20">We invest in five corere industry sectors where we have substantial
                            experience
                            and deep local
                            and international knowle Business & Financial Services; Heahcare; Indtustrial; Retail,
                            Consumer & Leisure; Technology, Media & Telecom.</p>
                        <a href="#" class="btn btn-outline-primary">know more<i
                                class="icon-arrows-slim-right ps-2"></i></a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 item materials">
                    <div class="px-30 bg-secondary text-white pt-4 pb-20 h-100 isotop-block">
                        <h4 class="text-underline-sm lh-1 pb-3 mb-3 pt-0">Materials</h4>
                        <p class="small mb-20">We invest in five corere industry sectors where we have substantial
                            experience
                            and deep local
                            and international knowle Business & Financial Services; Healthcare; Indtustrial; Retail,
                            Consumer & Leisure; Technology, Media & Telecom.</p>
                        <a href="#" class="btn btn-outline-primary">know more<i
                                class="icon-arrows-slim-right ps-2"></i></a>
                    </div>
                </div>


                <div class="col-lg-4 col-md-6 item all financials industrial">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/1-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-3.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="#" class="text-decoration-none">Industrial
                                                global</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Hill-FinAdvisor</p>
                                    </div>
                                </div>
                                <a href="#" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 item all information-tehnology materials">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/2-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-1.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="#" class="text-decoration-none">Information
                                                Warehouse</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Hill-FinAdvisor</p>
                                    </div>
                                </div>
                                <a href="#" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 item all financials materials">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/3-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-2.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="#" class="text-decoration-none">Materials
                                                technology</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Hill-FinAdvisor</p>
                                    </div>
                                </div>
                                <a href="#" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 item all industrial information-tehnology">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/4-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-3.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="#" class="text-decoration-none">Information
                                                tehnology</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Hill-FinAdvisor</p>
                                    </div>
                                </div>
                                <a href="#" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 item all energy">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/5-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-1.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="#" class="text-decoration-none">Industrial
                                                International</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Hill-FinAdvisor</p>
                                    </div>
                                </div>
                                <a href="#" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 item all energy">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/6-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-2.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="#" class="text-decoration-none">Energy
                                                Global</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Hill-FinAdvisor</p>
                                    </div>
                                </div>
                                <a href="#" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 item all energy">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/7-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-3.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="project-details.php" class="text-decoration-none">Technology
                                                Booster</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Hill-FinAdvisor</p>
                                    </div>
                                </div>
                                <a href="#" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 item all energy">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/8-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-4.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="#" class="text-decoration-none">Materials
                                                Warehouse</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Hill-FinAdvisor</p>
                                    </div>
                                </div>
                                <a href="#" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 item all energy">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/9-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-5.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="#" class="text-decoration-none">Financial
                                                International</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Hill-FinAdvisor</p>
                                    </div>
                                </div>
                                <a href="#" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!-- isotop section End -->

    <!-- team section  -->
    <section class="py-60">
        <div class="container">
            <div class="row gy-30">
                <div class="col-lg-4">
                    <div class="">
                        <h2 class="text-underline-sm pb-3 mb-3"><span class="text-primary pe-2">Hill-FinAdvisor</span>
                        </h2>
                        <p class="text-muted pb-3">Advent has one of the world’s largest and most experienced private
                            equity
                            teams, with more
                            than 170 investment professionals across four continents.</p>
                        <a href="member-all.php" class="btn btn-outline-primary text-dark">meet our team<i
                                class="icon-arrows-slim-right ps-2"></i></a>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div id="mySwiper-mg"
                        class="swiper pb-lg-0 pb-5 mySwiper swiper-initialized swiper-horizontal swiper-pointer-events">
                        <div class="swiper-wrapper parent-container" id="swiper-wrapper-151c11395903893b"
                            aria-live="polite" style="transition-duration: 0ms; transform: translate3d(0px, 0px, 0px);">
                            <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="0" role="group"
                                aria-label="1 / 3" style="width: 604.333px; margin-right: 30px;">

                                <div class="card single-team-member h-100">
                                    <div class="team-member-photo">
                                        <img src="assets/images/members/3.jpg" class="card-img-top"
                                            alt="service image">
                                        <a href="member-details.php"
                                            class="view-full-size text-decoration-none small text-uppercase lh-sm">
                                            <span class="text-white">know more</span>
                                        </a>
                                    </div>
                                    <div class="card-body">
                                        <a href="member-details.php" class="text-decoration-none">
                                            <h5 class="card-title fs-4 fw-normal">VICENA XIANG</h5>
                                        </a>
                                        <a href="#" class="text-decoration-none"><span
                                                class="extra-small fw-bold text-uppercase text-primary d-block mt-10 mb-3">CHIEF ADMINISTRATOR, Hill-FinAdvisor</span></a>
                                    </div>
                                </div>


                            </div>
                            <div class="swiper-slide" data-swiper-slide-index="1" role="group" aria-label="2 / 3"
                                style="width: 604.333px; margin-right: 30px;">

                                <div class="card single-team-member h-100">
                                    <div class="team-member-photo">
                                        <img src="assets/images/members/1.jpg" class="card-img-top"
                                            alt="service image">
                                        <a href="member-details.php"
                                            class="view-full-size text-decoration-none small text-uppercase lh-sm">
                                            <span class="text-white">know more</span>
                                        </a>
                                    </div>
                                    <div class="card-body">
                                        <a href="member-details.php" class="text-decoration-none">
                                            <h5 class="card-title fs-4 fw-normal">GRUBER ALFRED</h5>
                                        </a>
                                        <a href="#" class="text-decoration-none"><span
                                                class="extra-small fw-bold text-uppercase text-primary d-block mt-10 mb-3">PARTNER, Hill-FinAdvisor</span></a>
                                    </div>
                                </div>

                            </div>
                            <div class="swiper-slide" data-swiper-slide-index="2" role="group" aria-label="3 / 3"
                                style="width: 604.333px; margin-right: 30px;">


                                <div class="card single-team-member h-100">
                                    <div class="team-member-photo">
                                        <img src="assets/images/members/2.jpg" class="card-img-top"
                                            alt="service image">
                                        <a href="member-details.php"
                                            class="view-full-size text-decoration-none small text-uppercase lh-sm">
                                            <span class="text-white">know more</span>
                                        </a>
                                    </div>
                                    <div class="card-body">
                                        <a href="member-details.php" class="text-decoration-none">
                                            <h5 class="card-title fs-4 fw-normal">AELBERT MÜLLER</h5>
                                        </a>
                                        <a href="#" class="text-decoration-none"><span
                                                class="extra-small fw-bold text-uppercase text-primary d-block mt-10 mb-3">GENERAL COUNSEL, Hill-FinAdvisor</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="swiper-pagination-id"
                            class="swiper-pagination swiper-pagination-clickable swiper-pagination-bullets swiper-pagination-horizontal pb-4">
                            <span class="swiper-pagination-bullet swiper-pagination-bullet-active" tabindex="0"
                                role="button" aria-label="Go to slide 1" aria-current="true"></span>
                            <span class="swiper-pagination-bullet" tabindex="0" role="button"
                                aria-label="Go to slide 2"></span>
                            <span class="swiper-pagination-bullet" tabindex="0" role="button"
                                aria-label="Go to slide 3"></span>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- team section end -->

    <!-- download feature  -->
    <section class="bg-secondary">
        <div class="container">
            <div class="text-white text-center py-60">
                <p class="small text-uppercase fw-bold lh-lg letter-spacing-lg">We have invested $2.4 billion in 150
                    transactions<span class="d-block">across 11 countries”</span>
                </p>
                <h2 class="display-5 fw-bold pb-4 custom-letter-spacing-n">Download Our 2024 Highlights <span
                        class="text-primary">Review</span>
                </h2>
                <a href="#" class="btn btn-lg btn-primary py-3">
                    <img src="assets/images/icon-download.png" alt="Image" class="pe-2">
                    Download PDF<i class="icon-arrows-slim-right ps-2"></i>
                </a>
            </div>
        </div>
    </section>
    <!-- download feature end -->

    <!-- clients section  -->
    <section class="pt-60">
        <div class="container">
            <div class="pb-60 border-bottom">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="pe-4">
                            <p class="text-underline-sm fw-bold pb-3 text-muted text-uppercase">Our clients know</p>
                            <h2 class="custom-letter-spacing-n pb-2"><span class="text-primary">Hill-FinAdvisor</span>
                                is
                                one
                                of
                                the largest and most experienced
                                global private equity investors</h2>
                            <p class="text-muted">We seek to invest in well-positioned companies with operational and
                                strategic improvement
                                potential and partner with management teams to create value by driving revenue and
                                earnings
                                growth.</p>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-4">
                                <img src="assets/images/client-1.png" alt="clint" class="img-fluid">
                            </div>
                            <div class="col-4">
                                <img src="assets/images/client-2.png" alt="clint" class="img-fluid">
                            </div>
                            <div class="col-4">
                                <img src="assets/images/client-3.png" alt="clint" class="img-fluid">
                            </div>
                            <div class="col-4">
                                <img src="assets/images/client-4.png" alt="clint" class="img-fluid">
                            </div>
                            <div class="col-4">
                                <img src="assets/images/client-5.png" alt="clint" class="img-fluid">
                            </div>
                            <div class="col-4">
                                <img src="assets/images/client-6.png" alt="clint" class="img-fluid">
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- clients section end -->

    <!-- management team -->
    <section class="pt-100 pb-60">
        <div class="container">
            <div class="row gy-5 gallery-image">
                <div class="col-lg-6">
                    <div class="d-flex gap-4 flex-lg-nowrap flex-wrap ">
                        <div class="flex-shrink-0">
                            <div class="image-scale">
                                <a href="assets/images/eco-1.png" class="rounded-circle popup-img">
                                    <img src="assets/images/eco-1.png" alt="Eco">
                                </a>
                            </div>
                        </div>
                        <div class="flex-grow-1">
                            <h4 class="fw-normal">Alain</h4>
                            <p class="extra-small text-uppercase text-muted">Managing Director</p>
                            <p class="small text-muted">"
                            </p>
                            <img src="assets/images/painting-1.png" alt="signature">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="d-flex gap-4 flex-lg-nowrap flex-wrap ">
                        <div class="flex-shrink-0">
                            <div class="image-scale">
                                <a href="assets/images/eco-2.png" class="rounded-circle popup-img">
                                    <img src="assets/images/eco-2.png" alt="Eco">
                                </a>
                            </div>
                        </div>
                        <div class="flex-grow-1">
                            <h4 class="fw-normal">klein</h4>
                            <p class="extra-small text-uppercase text-muted">CEO Finance </p>
                            <p class="small text-muted">
                            </p>
                            <img src="assets/images/painting-1.png" alt="signature">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- management team end -->

    <!-- blog section -->
    <section class="py-60 bg-light">
        <div class="container">
            <div class="row gy-30 gallery-image">
                <div class="col-lg-4">
                    <h2 class="text-underline-sm pb-3 mb-3">Our <span class="text-primary">Blog</span></h2>
                    <p class="text-muted">HILLFIN-ADVISOR has one of the world’s largest and most experienced private equity
                        teams, with more than
                        170 investment professionals across four continents.</p>
                    <a href="#" class="btn btn-outline-primary text-dark">view all news<i
                            class="icon-arrows-slim-right ps-2"></i></a>
                </div>
                <div class="col-lg-8">

                    <div id="mySwiper-mg"
                        class="swiper pb-lg-0 pb-5 mySwiper swiper-initialized swiper-horizontal swiper-pointer-events">
                        <div class="swiper-wrapper parent-container" id="swiper-wrapper-151c11395903893b"
                            aria-live="polite" style="transition-duration: 0ms; transform: translate3d(0px, 0px, 0px);">
                            <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="0" role="group"
                                aria-label="1 / 3" style="width: 604.333px; margin-right: 30px;">

                                <div class="card">
                                    <div class="image-scale">
                                        <a href="assets/images/post-photo1-500x340.png" class="popup-img">
                                            <img src="assets/images/post-photo1-500x340.png" alt="Eco"
                                                class="img-fluid">
                                        </a>
                                    </div>
                                    <div class="card-body p-0">
                                        <p class="normal-small text-uppercase text-muted pt-3">May 10, 2024</p>
                                        <h4 class="card-title fw-normal mb-4">Hillfin-Advisor Expert raises $13 billion global private
                                            equity fund
                                        </h4>
                                        <a href="#" class="btn btn-xs btn-secondary">read more</a>
                                    </div>
                                </div>

                            </div>
                            <div class="swiper-slide" data-swiper-slide-index="1" role="group" aria-label="2 / 3"
                                style="width: 604.333px; margin-right: 30px;">

                                <div class="card">
                                    <div class="image-scale">
                                        <a href="assets/images/service-image1-500x340.jpg" class="popup-img">
                                            <img src="assets/images/service-image1-500x340.jpg" alt="Eco"
                                                class="img-fluid">
                                        </a>
                                    </div>
                                    <div class="card-body p-0">
                                        <p class="normal-small text-uppercase text-muted pt-3">May 20, 2024</p>
                                        <h4 class="card-title fw-normal mb-4">Hillfin-Advisor Expert raises $10 billion global private
                                            equity fund
                                        </h4>
                                        <a href="#" class="btn btn-xs btn-secondary">read more</a>
                                    </div>
                                </div>

                            </div>
                            <div class="swiper-slide" data-swiper-slide-index="2" role="group" aria-label="3 / 3"
                                style="width: 604.333px; margin-right: 30px;">

                                <div class="card">
                                    <div class="image-scale">
                                        <a href="assets/images/post-photo3-500x340.png" class="popup-img">
                                            <img src="assets/images/post-photo3-500x340.png" alt="Eco"
                                                class="img-fluid">
                                        </a>
                                    </div>
                                    <div class="card-body p-0">
                                        <p class="normal-small text-uppercase text-muted pt-3">May 15, 2024</p>
                                        <h4 class="card-title fw-normal mb-4">Hillfin-Advisor Expert raises $13 billion global private
                                            equity fund
                                        </h4>
                                        <a href="#" class="btn btn-xs btn-secondary">read more</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="swiper-pagination-id"
                            class="swiper-pagination swiper-pagination-clickable swiper-pagination-bullets swiper-pagination-horizontal pb-4">
                            <span class="swiper-pagination-bullet swiper-pagination-bullet-active" tabindex="0"
                                role="button" aria-label="Go to slide 1" aria-current="true"></span>
                            <span class="swiper-pagination-bullet" tabindex="0" role="button"
                                aria-label="Go to slide 2"></span>
                            <span class="swiper-pagination-bullet" tabindex="0" role="button"
                                aria-label="Go to slide 3"></span>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- blog section end -->

    <!-- footer banner -->
    <section class="footer-banner bg-dark text-white">
        <div class="container">
            <div class="d-flex flex-wrap justify-content-lg-between justify-content-center text-center">
                <h1 class="display-5">Make A Difference With <span class="text-primary">Hillfin-Advisor</span></h1>
                <div>
                    <a href="contact-us.php" class="btn btn-lg btn-primary">Let’s Work Together<i
                            class="icon-arrows-slim-right ps-2"></i></a>
                </div>
            </div>
        </div>
    </section>
    <!-- footer banner end -->

    <!-- footer section -->

    <?php include "footer.php" ?>
    
    <!-- footer section end -->
    <a id="scrollUp" onclick="topFunction()" title="Go to top"><i class="fa-solid fa-angle-up"></i>
    </a>

    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- chart.js  -->
    <script src="assets/js/chart.min.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/custom.js"></script>

</body>



</html>