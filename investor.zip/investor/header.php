<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hillfrin-Advisor</title>
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cardo:wght@400;700&amp;family=Lato:wght@300;400;700&amp;display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="assets/css/linea.css">
    <link rel="stylesheet" href="assets/css/pe-icon-7-stroke.css">
    <link rel="stylesheet" href="assets/css/perch.css">
    <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/bootstrap-icon.css">

    <!-- magnafic popup -->
    <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
    <link rel="shortcut icon" href="#">
</head>

<body>
    <!-- header-section -->
    <header id="navbar_top" class="transparent-header">
        <div class="top-bar bg-secondary py-2 py-lg-0">
            <div class="container">
                <div class="d-flex gap-4 flex-wrap justify-content-lg-end align-items-center">
                    <div>
                        <i class="fa-regular fa-clock text-primary"></i>
                        <span class="text-white ps-2">Mon - Fri : 09:00am - 06:00pm</span>
                    </div>
                    <div> 
                        <i class="fa-solid fa-phone text-primary"></i>
                        <span class="text-white ps-2">+32-4602-48617</span>
                    </div>
                    <div class="d-sm-flex d-none">
                        <span><a href="contact.php" class="btn btn-sm btn-primary">Work with us</a></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light py-3 py-lg-0">
                <a class="site-logo navbar-brand" href="home-1.php" rel="home">
                    <img class="logo-dark" src="dark.png" width="250" height="40"
                        alt="Investment Experts">
                    <img class="logo-light" src="dark.png" width="250" height="40"
                        alt="Investment Experts">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#main_nav"
                    aria-controls="main_nav">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="offcanvas offcanvas-lg offcanvas-end bg-dark p-3 p-lg-0" id="main_nav" tabindex="-1">
                    <div class="offcanvas-body align-items-center">
                        <div class="offcanvas-header px-0 justify-content-end">
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"
                                aria-label="Close"></button>
                        </div>
                        <ul class="navbar-nav ms-lg-auto">
                        <li class="nav-item"><a class="nav-link" href="about-us.php">About Us</a></li>
                        <li class="nav-item"><a class="nav-link" href="index-2.php">Principle</a></li>
                         <li class="nav-item"><a class="nav-link" href="job-details.php">Investment Criteria</a></li>
                         <li class="nav-item"><a class="nav-link" href="job-details-2.php">Investment Services</a></li>
                         <li class="nav-item"><a class="nav-link" href="contact-us.php">Investment Process</a></li>
                            <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                        </ul>
                        <div class="ps-lg-3 social-logo gap-5 align-items-center">
                            <div class="social-logo-light gap-3">
                                <a href="#" class="text-decoration-none">
                                    <i class="fa-brands fa-facebook-f"></i>
                                </a>
                                <a href="#" class="text-decoration-none">
                                    <i class="fa-brands fa-twitter"></i>
                                </a>
                                <a href="#" class="text-decoration-none">
                                    <i class="fa-brands fa-whatsapp"></i>
                                </a>
                            </div>
                            <div class="social-logo-dark">
                                <span><a href="contact.php" class="btn btn-sm btn-primary">Work with us</a></span>
                            </div>
                        </div>
                    </div>
                </div> <!-- navbar-collapse.// -->

            </nav>
        </div> <!-- container.// -->
    </header>
    <!-- header-section end -->