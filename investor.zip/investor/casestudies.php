<?php include "header.php" ?>

    <section class="banner-section position-relative overflow-hidden bg-dark text-white">
        <div class="parallax bg-cover position-absolute start-0 top-0 w-100 h-100 opacity-50"></div>
        <div class="container">
            <h2 class="underline-bold fw-bold fs-1 mb-3 pb-3">Casestudies</h2>
            <nav aria-label="breadcrumb" class="breadcrumb-text">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index-2.html">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Casestudies</li>
                </ol>
            </nav>
        </div>

    </section>


    <section class="casestudies-section py-60">
        <div class="container">
            <div class="row g-2">
                <div class="col-lg-4">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/1-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-3.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="project-details.html" class="text-decoration-none">Industrial
                                                global</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Financials, Industrial</p>
                                    </div>
                                </div>
                                <a href="project-details.html" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/2-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-1.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="project-details.html" class="text-decoration-none">Information
                                                Warehouse</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Information tehnology, Materials</p>
                                    </div>
                                </div>
                                <a href="project-details.html" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/3-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-2.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="project-details.html" class="text-decoration-none">Materials
                                                technology</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Financials, Materials</p>
                                    </div>
                                </div>
                                <a href="project-details.html" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/4-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-3.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="project-details.html" class="text-decoration-none">Information
                                                tehnology</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Industrial, Information tehnology</p>
                                    </div>
                                </div>
                                <a href="project-details.html" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/5-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-1.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="project-details.html" class="text-decoration-none">Industrial
                                                International</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Energy</p>
                                    </div>
                                </div>
                                <a href="project-details.html" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/6-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-2.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="project-details.html" class="text-decoration-none">Energy
                                                Global</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Energy</p>
                                    </div>
                                </div>
                                <a href="project-details.html" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/7-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-3.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="project-details.html" class="text-decoration-none">Technology
                                                Booster</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Energy</p>
                                    </div>
                                </div>
                                <a href="project-details.html" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/8-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-4.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="project-details.html" class="text-decoration-none">Materials
                                                Warehouse</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Energy</p>
                                    </div>
                                </div>
                                <a href="project-details.html" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="item-inner position-relative overflow-hidden">
                        <img src="assets/images/casestudy/9-360x227.jpg" alt="image" class="background-item w-100">
                        <div class="position-absolute bottom-0 w-100">
                            <div class="item-content d-grid gap-20 px-30">
                                <div class="d-flex gap-20 align-items-center">
                                    <img src="assets/images/portfolio-logo-5.png" alt="logo">
                                    <div class="text-white">
                                        <h4 class="mb-0">
                                            <a href="project-details.html" class="text-decoration-none">Financial
                                                International</a>
                                        </h4>
                                        <p class="extra-small text-uppercase mb-0">Energy</p>
                                    </div>
                                </div>
                                <a href="project-details.html" class="btn btn-sm btn-primary">Find out more<i
                                        class="icon-arrows-slim-right ps-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="footer-banner bg-dark text-white">
        <div class="container">
            <div class="d-flex flex-wrap justify-content-lg-between justify-content-center text-center">
                <h1 class="display-5">Make A Difference With <span class="text-primary">Expert Team</span></h1>
                <div>
                    <a href="contact-us.html" class="btn btn-lg btn-primary">Let’s Work Together<i
                            class="icon-arrows-slim-right ps-2"></i></a>
                </div>
            </div>
        </div>
    </section>


    <!-- footer section -->


    <?php include "footer.php" ?>

    <!-- footer section end -->
    <a id="scrollUp" onclick="topFunction()" title="Go to top"><i class="fa-solid fa-angle-up"></i>
    </a>

    <script src="assets/js/jquery-3.6.0.min.js"></script>

    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/custom.js"></script>

</body>


<!-- Mirrored from investmentwp.com/html/casestudies.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 27 May 2024 22:00:39 GMT -->
</html>