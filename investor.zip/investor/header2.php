<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from investmentwp.com/html/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 27 May 2024 21:59:27 GMT -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Investment Template</title>
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cardo:wght@400;700&amp;family=Lato:wght@300;400;700&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/linea.css">
    <link rel="stylesheet" href="assets/css/pe-icon-7-stroke.css">
    <link rel="stylesheet" href="assets/css/perch.css">
    <link rel="stylesheet" href="assets/css/swiper-bundle.min.css">

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/bootstrap-icon.css">

    <!-- magnafic popup -->
    <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
    <link rel="shortcut icon" href="#">
</head>

<body>
    <!-- header-section -->
    <header id="navbar_top" class="transparent-header position-fixed">
        <div class="top-bar py-2 py-lg-0">
            <div class="container">
                <div class="d-flex gap-4 flex-wrap justify-content-lg-end align-items-center">
                    <div>
                        <i class="fa-regular fa-clock text-primary"></i>
                        <span class="text-white ps-2">Mon - Fri : 09:00 - 17:00</span>
                    </div>
                    <div>
                        <i class="fa-solid fa-phone text-primary"></i>
                        <span class="text-white ps-2">888-123-2342</span>
                    </div>
                    <div class="d-sm-flex d-none">
                        <span><a href="contact.html" class="btn btn-sm btn-primary">Work with us</a></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-dark py-3 py-lg-0 border-bottom">
                <a class="site-logo navbar-brand" href="index-2.html" rel="home">
                    <img class="logo-dark" src="assets/images/logo.png" width="250" height="40"
                        alt="Investment Experts">
                    <img class="logo-light" src="assets/images/logo-white.png" width="250" height="40"
                        alt="Investment Experts">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#main_nav"
                    aria-controls="main_nav">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="offcanvas offcanvas-lg offcanvas-end bg-dark p-3 p-lg-0" id="main_nav" tabindex="-1">
                    <div class="offcanvas-body align-items-center">
                        <div class="offcanvas-header px-0 justify-content-end">
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas"
                                aria-label="Close"></button>
                        </div>
                        <ul class="navbar-nav ms-lg-auto">
                            <li class="nav-item dropdown position-relative">
                                <a class="nav-link active" href="index-2.html">Home</a>
                                <span class="caret nav-indicator d-lg-none d-block" data-bs-toggle="dropdown"></span>
                                <ul class="dropdown-menu fade-down">
                                    <li><a class="dropdown-item" href="home-1.html">Home style 1</a></li>
                                    <li><a class="dropdown-item" href="home-2.html">Home style 2</a></li>
                                    <li><a class="dropdown-item" href="home-3.html">Home style 3</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link" href="#">Features</a>
                                <span class="caret nav-indicator d-lg-none d-block" data-bs-toggle="dropdown"></span>
                                <ul class="dropdown-menu fade-down">
                                    <li><a class="dropdown-item" href="about-us.html">Company overview</a></li>
                                    <li><a class="dropdown-item" href="our-history.html">Our history</a></li>
                                    <li><a class="dropdown-item" href="how-we-work.html">How we work</a></li>
                                    <li><a class="dropdown-item" href="services.html">Services</a>
                                        <ul class="dropdown-menu d-block">
                                            <li><a class="dropdown-item" href="service-details-1.html">Services details
                                                    style #1</a></li>
                                            <li><a class="dropdown-item" href="service-details-2.html">Services details
                                                    style #2</a></li>
                                        </ul>
                                    </li>
                                    <li><a class="dropdown-item" href="#">Team member</a>
                                        <ul class="dropdown-menu d-block">
                                            <li><a class="dropdown-item" href="member-all.html">All members</a>
                                            </li>
                                            <li><a class="dropdown-item" href="member-details.html">Member details
                                                    page</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a class="dropdown-item" href="careers.html">Careers</a>
                                        <ul class="dropdown-menu d-block">
                                            <li><a class="dropdown-item" href="job-details.html">Job details page</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a class="dropdown-item" href="partners.html">Partners</a></li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link" href="casestudies.html">Casestudies</a>
                                <span class="caret nav-indicator d-lg-none d-block" data-bs-toggle="dropdown"></span>
                                <ul class="dropdown-menu  fade-down">
                                    <li><a class="dropdown-item" href="casestudies.html">Case Studies Protfolio</a></li>
                                    <li><a class="dropdown-item" href="project-details.html">Project details page</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link" href="services.html">Services</a>
                                <span class="caret nav-indicator d-lg-none d-block" data-bs-toggle="dropdown"></span>
                                <ul class="dropdown-menu  fade-down">
                                    <li><a class="dropdown-item" href="services.html">All Services</a></li>
                                    <li><a class="dropdown-item" href="service-details-1.html">Services details style
                                            #1</a>
                                    </li>
                                    <li><a class="dropdown-item" href="service-details-2.html">Services details style
                                            #2</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item"><a class="nav-link" href="news.html">News</a></li>
                            <li class="nav-item"><a class="nav-link" href="contact.html">Contact</a></li>
                        </ul>

                        <div class="ps-lg-3 social-logo gap-5 align-items-center">
                            <div class="social-logo-light gap-3">
                                <a href="#" class="text-decoration-none">
                                    <i class="fa-brands fa-facebook-f"></i>
                                </a>
                                <a href="#" class="text-decoration-none">
                                    <i class="fa-brands fa-twitter"></i>
                                </a>
                                <a href="#" class="text-decoration-none">
                                    <i class="fa-brands fa-linkedin-in"></i>
                                </a>
                            </div>
                            <div class="social-logo-dark">
                                <span><a href="contact.html" class="btn btn-sm btn-primary">Work with us</a></span>
                            </div>
                        </div>
                    </div>
                </div> <!-- navbar-collapse.// -->

            </nav>
        </div> <!-- container.// -->
    </header>
    <!-- header-section end -->