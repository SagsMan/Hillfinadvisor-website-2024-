   <?php include "header.php" ?>

    <section class="banner-section position-relative overflow-hidden bg-dark text-white">
        <div class="parallax bg-cover position-absolute start-0 top-0 w-100 h-100 opacity-50"></div>
        <div class="container">
            <h2 class="underline-bold fw-bold fs-1 mb-3 pb-3">Cantact Us</h2>
            <nav aria-label="breadcrumb" class="breadcrumb-text">
                <ol class="breadcrumb">
                   
                </ol>
            </nav>
        </div>
    </section>

    <section class="news-section py-60">
        <div class="container">

            <div class="mb-5">
                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab"
                            data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home"
                            aria-selected="true"><span>Hill-FinAdvisor Office</span></button>

                        <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile"
                            type="button" role="tab" aria-controls="nav-profile" aria-selected="false"><span>Hill-FinAdvisor Strategy</span></button>

                        <button class="nav-link" id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact"
                            type="button" role="tab" aria-controls="nav-contact" aria-selected="false"><span>Hill-FinAdvisor Analytical Statistics</span></button>

                        <button class="nav-link" id="nav-contact-tab2" data-bs-toggle="tab"
                            data-bs-target="#nav-contact2" type="button" role="tab" aria-controls="nav-contact2"
                            aria-selected="false"><span>Hill-FinAdvisor Income Data</span></button>
                    </div>
                </nav>
                <div class="tab-content" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab"
                        tabindex="0">
                        <div>
                            <iframe class="w-100"
                                src="assets/images/casestudy/3-360x227.jpg" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab"
                        tabindex="0">
                        <div>
                            <iframe class="w-100"
                                src="assets/images/home-banner-bg.jpg"
                                height="350" style="border:0;" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab"
                        tabindex="0">
                        <div>
                            <iframe class="w-100"
                                src="assets/images/post-photo3-500x340.png" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-contact2" role="tabpanel" aria-labelledby="nav-contact-tab2"
                        tabindex="0">
                        <div>
                            <iframe class="w-100"
                                src="assets/images/casestudy/1-360x227.jpg"
                                height="350" style="border:0;" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-4">
                    <h1 class="text-underline fw-bold fs-2 mb-30 pb-20">Get in Touch</h1>
                    <ul class="contact-icon list-unstyled ps-0 d-grid gap-10 mb-5">
                        <li>
                            <a href="#" class="text-decoration-none text-dark text-opacity-75 me-40">
                                <span>Rue de la Loi 107 1000 Bruxelles / Brussel, Belgium Europe.</span>
                            </a>
                        </li>
                        <li>
                            <a href="tel:(214) 550-0405"
                                class="text-decoration-none d-flex gap-3 text-dark text-opacity-75">
                                <i class="fa-solid fa-whatsap text-primary"></i>
                                <span>+32-4602-48617</span></a>
                        </li>
                        <li>
                            <a href="+32-4602-48617"
                                class="text-decoration-none d-flex gap-3 text-dark text-opacity-75">
                                <i class="fa-solid fa-phone text-primary"></i>
                                <span>+32-4602-48617</span></a>
                        </li>
                        <li>
                            <a href="mailto:info@themeperch.net"
                                class="text-decoration-none d-flex gap-3 text-dark text-opacity-75">
                                <i class="fa-solid fa-envelope-open-text text-primary"></i>
                                <span>Email: info@Hill-FinAdvisorcapitalinvest.com</span>
                            </a>
                        </li>

                    </ul>

                    <h1 class="text-underline fw-bold fs-2 mb-30 pb-20">Hill-FinAdvisors Working Hours</h1>
                    <ul class="list-unstyled ps-0 d-grid gap-20 mb-5">
                        <li>
                            <p class="mb-0">Monday to Friday</p>
                            <p class="text-dark text-opacity-75 fw-bold mb-0 heading-font">8.00am - 5.30pm</p>
                        </li>

                        <li>
                            <p class="mb-0">Saturday</p>
                            <p class="text-dark text-opacity-75 fw-bold mb-0 heading-font">9.00am - 2.00pm</p>
                        </li>

                        <li>
                            <p class="mb-0">Sunday</p>
                            <p class="text-dark text-opacity-75 fw-bold mb-0 heading-font">Closed</p>
                        </li>

                    </ul>
                </div>
                <div class="col-lg-8">
                    <form class="row gx-4 gy-30">
                        <div class="col-md-6">
                            <span class="required-field">
                                <input type="text" class="form-control" id="inputFname" placeholder="First name"
                                    required>
                            </span>
                        </div>
                        <div class="col-md-6">
                            <span class="required-field">
                                <input type="text" class="form-control" id="inputLname" placeholder="Last name"
                                    required>
                            </span>
                        </div>
                        <div class="col-md-6">
                            <span class="required-field">
                                <input type="email" class="form-control" id="inputEmail" placeholder="Your E-mail"
                                    required>
                            </span>
                        </div>
                        <div class="col-md-6">
                            <input type="text" class="form-control" id="inputPhone" placeholder="Your Phone Number">
                        </div>
                        <div class="col-md-6">
                            <input type="text" class="form-control" id="inputweb" placeholder="Website">
                        </div>
                        <div class="col-md-6">
                            <span class="required-field">
                                <select id="inputState" class="form-select" required>
                                    <option selected>Department</option>
                                    <option>Finance</option>
                                    <option>Investment</option>
                                    <option>Others</option>
                                </select>
                            </span>
                        </div>

                        <div class="col-md-12">
                            <span class="required-field">
                                <textarea class="form-control" placeholder="Your message" id="floatingTextarea2"
                                    rows="10" cols="40"></textarea>
                            </span>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-secondary">Sent a message</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <section class="footer-banner bg-dark text-white">
        <div class="container">
            <div class="d-flex flex-wrap justify-content-lg-between justify-content-center text-center">
                <h1 class="display-5">Make A Difference With <span class="text-primary">Hill-FinAdvisor</span></h1>
                <div>
                    <a href="contact-us.html" class="btn btn-lg btn-primary">Let’s Work Together<i
                            class="icon-arrows-slim-right ps-2"></i></a>
                </div>
            </div>
        </div>
    </section>


    <!-- footer section -->


    <?php include "footer.php" ?>


    <!-- footer section end -->
    <a id="scrollUp" onclick="topFunction()" title="Go to top"><i class="fa-solid fa-angle-up"></i>
    </a>

    <script src="assets/js/jquery-3.6.0.min.js"></script>

    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/custom.js"></script>

</body>


<!-- Mirrored from investmentwp.com/html/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 27 May 2024 22:00:25 GMT -->
</html>