
<footer id="footer" class="footer-section bg-secondary pt-5 text-white text-opacity-75">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4 col-12">
                    <a href="index-2.html"><img src="assets/images/invest.png" alt="Footer logo"
                            class="img-fluid mb-4" width="311" height="48"></a>
                    <p class="">Hillfin-Advisor Capital, established in 1983, manages investments for clients from Europe, the USA, Asia, and the Gulf. They offer low-interest loans, equity investments, and Swiss credit, with a senior management team boasting over 35 years of experience. They also provide commercial insurance products and reinsurance, maintaining strict client confidentiality. Their professionalism has led to partnerships with governments, public companies, and private project owners.</p>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="footer-links">
                        <h6 class="mb-4 fw-semibold text-white">USEFUL LINKS</h6>
                        <ul class="list-unstyled d-grid gap-1">
                            <li>
                                <a href="about-us.php"
                                    class="text-decoration-none d-flex gap-2 text-white text-opacity-75">
                                    <i class="bi bi-arrow-right text-primary"></i>
                                    <span>About us</span>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="text-decoration-none d-flex gap-2 text-white text-opacity-75">
                                    <i class="bi bi-arrow-right text-primary"></i>
                                    <span>Casestudies</span>
                                </a>
                            </li>
                            <li>
                                <a href="services.html"
                                    class="text-decoration-none d-flex gap-2 text-white text-opacity-75">
                                    <i class="bi bi-arrow-right text-primary"></i>
                                    <span>Services</span>
                                </a>
                            </li>
                            <li>
                                <a href="how-we-work.html"
                                    class="text-decoration-none d-flex gap-2 text-white text-opacity-75">
                                    <i class="bi bi-arrow-right text-primary"></i>
                                    <span>How we work</span>
                                </a>
                            </li>
                            <li>
                                <a href="#"
                                    class="text-decoration-none d-flex gap-2 text-white text-opacity-75">
                                    <i class="bi bi-arrow-right text-primary"></i>
                                    <span>Our history</span>
                                </a>
                            </li>
                            <li>
                                <a href="#" class="text-decoration-none d-flex gap-2 text-white text-opacity-75">
                                    <i class="bi bi-arrow-right text-primary"></i>
                                    <span>Drop us a line</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-6">
                    <h6 class="mb-4 fw-semibold text-white">HILLFIN-ADVISOR</h6>
                    <ul class="list-unstyled ps-0 d-grid gap-2">
                        <li>
                            <a href="#" class="text-decoration-none d-flex gap-2 text-white text-opacity-75">
                                <i class="fa-solid fa-location-dot text-primary"></i>
                                <span>Rue de la Loi 107 1000 Bruxelles / Brussel, Belgium Europe.</span>
                            </a>
                        </li>
                        <li>
                            <a href="+32-4602-48617"
                                class="text-decoration-none d-flex gap-2 text-white text-opacity-75">
                                <i class="fa-solid fa-phone text-primary"></i>
                                <span>Tel: +32-4602-48617</span></a>
                        </li>
                        <li>
                            <a href="+32-4669-05498"
                                class="text-decoration-none d-flex gap-2 text-white text-opacity-75">
                                <i class="fa-solid fa-phone text-primary"></i>
                                <span>Fax :+32-4669-05498</span></a>
                        </li>
                        <li>
                            <a href=""
                                class="text-decoration-none d-flex gap-2 text-white text-opacity-75">
                                <i class="fa-solid fa-envelope-open-text text-primary"></i>
                                <span>Hill-FinAdvisor.com</span>
                            </a>
                        </li>

                    </ul>
                </div>
                <div class="col-lg-3 col-12">
                    <h6 class="mb-4 fw-semibold text-white">NEWSLETTER</h6>
                    <p>Signup for our latest case studies.</p>

                    <form action="#" method="post">
                        <div class="input-group">
                            <input type="text" class="form-control form-control-sm"
                                placeholder="Enter your email address.." aria-label="Recipient's username"
                                aria-describedby="basic-addon2" required>
                            <div class="input-group-btn">
                                <button type="submit" class="input-group-text" id="basic-addon2">
                                    <i class="icon-arrows-slim-right"></i>
                                </button>
                            </div>
                        </div>
                    </form>

                    <ul class="list-unstyled d-flex gap-4 pt-4">
                        <li><a href="#" target="_blank" class="text-white text-opacity-75"><i
                                    class="fa-brands fs-5 fa-facebook-f"></i></a></li>
                        <li><a href="#" target="_blank" class="text-white text-opacity-75"><i
                                    class="fa-brands fs-5 fa-twitter"></i></a></li>
                        <li><a href="#" target="_blank" class="text-white text-opacity-75"><i
                                    class="fa-brands fs-5 fa-whatsapp"></i></a>
                        </li>
                        <li><a href="#" target="_blank" class="text-white text-opacity-75"><i
                                    class="fa-brands fs-5 fa-youtube"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="copyright bg-dark mt-5">
            <div class="container">
                <div class="d-flex justify-content-between align-items-center flex-wrap py-4">
                    <p class="mb-lg-0">&copy;<?php echo date('d m y'); ?> Hillfin-Advisor. All Rights Reserved.</p>
                    <ul class="list-unstyled d-flex gap-3 mb-0">
                        <li><a href="contact.php"
                                class="text-decoration-none text-white text-opacity-75"><span>Contact
                                    us</span></a></li>
                        <li><a href="#" class="text-decoration-none text-white text-opacity-75"><span>Terms &
                                    Conditions</span></a></li>
                        <li><a href="#" class="text-decoration-none text-white text-opacity-75"><span>Privacy
                                    policy</span></a></li>
                    </ul>
                </div>
            </div>
        </div>


    </footer>